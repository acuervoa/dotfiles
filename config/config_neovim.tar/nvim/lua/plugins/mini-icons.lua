return {
	"nvim-mini/mini.icons",
	version = "*",
	config = function()
		require("mini.icons").setup()
	end,
}
