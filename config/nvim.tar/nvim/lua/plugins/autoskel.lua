return {
  {
    dir = "/home/af601888/Workspace/autoskel.nvim",
    name = "autoskel.nvim",
    dev = true,
    config = function()
      require("autoskel").setup()
    end,
  },
}
